package com.phone.musicapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = GridLayoutManager(this, 2)

        val musicList = listOf(
            MusicItem(R.drawable.rock, "Rock"),
            MusicItem(R.drawable.jazz, "Jazz"),
            MusicItem(R.drawable.pop, "Pop"),
            MusicItem(R.drawable.hiphop, "Hip-Hop"),
            MusicItem(R.drawable.classical, "Classical"),
            MusicItem(R.drawable.electronic, "Electronic"),
        )

        recyclerView.adapter = MusicAdapter(musicList)
    }
}
