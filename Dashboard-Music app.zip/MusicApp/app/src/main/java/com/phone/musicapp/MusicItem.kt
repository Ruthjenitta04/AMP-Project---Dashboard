package com.phone.musicapp

data class MusicItem(val imageRes: Int, val title: String)
